import React from 'react';
import axios from "axios"
import { useNavigate } from 'react-router-dom'
import { useState } from 'react';





const Login = () => {

    var auth = JSON.stringify(localStorage.getItem("auth"))
    console.log("this is auth string :" + auth);

    const nav = useNavigate();


    const [input, setInput] = useState({
        username: "",
        password: "",



    });


    const inputEvent = (event) => {

        const { name, value } = event.target;
        setInput((previousvalue) => {
            console.log(previousvalue.data);
            return {
                ...previousvalue,
                [name]: value,
            }



        });
    };
    const showdata = (event) => {
        event.preventDefault();

        try {
            axios.post("http://localhost:8682/auth", {
                username: input.username,
                password: input.password,

            })
                .then(response => {
                    console.log(response);

                    localStorage.setItem("jwt", JSON.stringify(response.data.response))
                    console.log(JSON.stringify(localStorage.getItem("jwt")))


                    nav("/Admin");






                }, error => {
                    alert("Fail");
                    console.log(error);
                })

                axios.post('http://localhost:8682/auth', data)
          .then(function (response) {
            if (response && response.data) {
              if (response.data === "logged in") {
                navigate('/services')
              }
              else {
                alert("wrong credentials.")
              }
            }

          })






        }
        catch (error) {
            console.log("error is", error)
        };


    }



    return (
        <>
            
            
            <div class="form-bg" style={{ paddingLeft: "35%",paddingTop:"5%", height:"550px",  backgroundColor: "#c3d6d9" }}>
                <div class="container">
                    <div class="row">
                        <div class="col-md-offset-4 col-md-4 col-sm-offset-3 col-sm-6">
                            <div class="form-container">
                                <form class="form-horizontal">
                                    <h3 class="title">User Login</h3>
                                    <div class="form-group">
                                        <span class="input-icon"><i class="fa fa-user"></i></span>
                                        <input class="form-control" type="text" name="username" placeholder="Username" onChange={inputEvent} value={input.username} required />
                                    </div>
                                    <div class="form-group">
                                        <span class="input-icon"><i class="fa fa-lock"></i></span>
                                        <input class="form-control" name="password" type="password" placeholder="Password" onChange={inputEvent} value={input.password} required />
                                    </div>
                                    <span class="forgot-pass"><a href="#">Lost password?</a></span>
                                    <span class="forgot-pass"><a href="/signup">signup here</a></span>
                                    <button class="btn signin" onClick={showdata}>Login</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            

            
            
            

            
        </>

    )
}

export default Login
