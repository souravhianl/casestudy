package com.ondemandcarwash.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.ondemandcarwash.model.Payments;
import com.ondemandcarwash.service.PaymentService;
@RestController
@CrossOrigin("http://localhost:3000")
@RequestMapping("/payment")
public class PaymentController {
    @Autowired
    public PaymentService service;

    @PostMapping("/pay")
    public Payments doPayment(@RequestBody Payments payment){
        return service.doPay(payment);
    }}